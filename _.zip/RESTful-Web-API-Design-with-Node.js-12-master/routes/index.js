export { rootRouter } from "./root";
